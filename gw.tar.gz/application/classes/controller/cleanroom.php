<?php defined('SYSPATH') or die('No direct access allowed.');

class Controller_Cleanroom extends Controller {

	public function action_index()
	{
		$c = 3;
		$e = 6;
		
		$signup = ORM::factory('signup', array('event_id' => $e, 'character_id' => $c))->find();
		
		if ($signup->loaded())
		{
			$this->response->body('Signup loaded');
		}
		else
		{
			$this->response->body('<pre>'.print_r($signup).'</pre>');
		}
		
		//$this->response->body(ProfilerToolbar::render(TRUE));
		
	}

}