<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Welcome extends Abstract_Controller_Website {

	public function action_index(){}

} // End Welcome
