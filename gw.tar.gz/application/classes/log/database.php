<?php defined('SYSPATH') or die('No direct access allowed.');

class Log_Database extends Kohana_Log_Database {}