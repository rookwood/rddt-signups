<?php defined('SYSPATH') or die('No direct access allowed.');

class View_Page_User_Email extends Abstract_View_Page {}