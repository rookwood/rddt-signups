<?php defined('SYSPATH') or die('No direct script access.');

class View_Page_Welcome_Index extends Abstract_View_Page {

	public $title = 'User Administration Module';

}