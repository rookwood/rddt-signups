<?php defined('SYSPATH') or die('No direct access allowed.');

return array(

	// Role required to edit own user profile - use 'login' to allow everyone
	'edit_profile_role' => 'login',

);