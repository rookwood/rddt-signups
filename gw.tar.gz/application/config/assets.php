<?php defined('SYSPATH') or die('No direct script access.');

return array (
	
	'default' => array(
		// array('script', 'http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js', 'body'),
		// array('script', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js', 'body', 10),
	),
	'css_main' => array(
		// array('style', '/media/css/styles.css', 'head'),
	),
	
);