<?php defined('SYSPATH') or die('No direct access allowed.');

return array
(

	// Patch to the images
	'image_path' => 'media/img/',

);
