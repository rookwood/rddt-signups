<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-04-02 21:21:59 --- ERROR: Database_Exception [ 2 ]: mysql_connect(): Access denied for user 'gw'@'localhost' (using password: YES) ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 67 ]
2012-04-02 21:21:59 --- STRACE: Database_Exception [ 2 ]: mysql_connect(): Access denied for user 'gw'@'localhost' (using password: YES) ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 67 ]
--
#0 /home/matt/workspace/modules/profilertoolbar/classes/kohana/database/mysql.php(470): Kohana_Database_MySQL->connect()
#1 /home/matt/workspace/modules/database/classes/kohana/database.php(478): Kohana_Database_MySQL->escape('auth')
#2 /home/matt/workspace/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote('auth')
#3 /home/matt/workspace/modules/database/classes/kohana/database/query/builder/select.php(366): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL), Array)
#4 /home/matt/workspace/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Select->compile(Object(Database_MySQL))
#5 /home/matt/workspace/modules/database/classes/kohana/config/database/reader.php(62): Kohana_Database_Query->execute('default')
#6 /home/matt/workspace/modules/database/classes/kohana/config/database/writer.php(26): Kohana_Config_Database_Reader->load('auth')
#7 /home/matt/workspace/system/classes/kohana/config.php(124): Kohana_Config_Database_Writer->load('auth')
#8 /home/matt/workspace/modules/auth/classes/kohana/auth.php(26): Kohana_Config->load('auth')
#9 /home/matt/workspace/application/classes/abstract/controller/website.php(18): Kohana_Auth::instance()
#10 [internal function]: Abstract_Controller_Website->before()
#11 /home/matt/workspace/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Welcome))
#12 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#15 {main}
2012-04-02 21:25:47 --- ERROR: ErrorException [ 1 ]: Class 'Assets' not found ~ APPPATH/classes/abstract/controller/website.php [ 45 ]
2012-04-02 21:25:47 --- STRACE: ErrorException [ 1 ]: Class 'Assets' not found ~ APPPATH/classes/abstract/controller/website.php [ 45 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-02 21:28:24 --- ERROR: ErrorException [ 1 ]: Call to undefined method Assets::factory() ~ APPPATH/classes/abstract/controller/website.php [ 45 ]
2012-04-02 21:28:24 --- STRACE: ErrorException [ 1 ]: Call to undefined method Assets::factory() ~ APPPATH/classes/abstract/controller/website.php [ 45 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-02 21:31:07 --- ERROR: UnexpectedValueException [ 0 ]: Tried to check for a role that did not exist. ~ APPPATH/classes/model/user.php [ 160 ]
2012-04-02 21:31:07 --- STRACE: UnexpectedValueException [ 0 ]: Tried to check for a role that did not exist. ~ APPPATH/classes/model/user.php [ 160 ]
--
#0 /home/matt/workspace/application/classes/abstract/view/page.php(72): Model_User->is_a('verified_user')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->links()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('links', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('links')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#5 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#6 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#7 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#8 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#9 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Welcome_Index))
#10 [internal function]: Abstract_Controller_Website->after()
#11 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Welcome))
#12 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#15 {main}
2012-04-02 21:32:16 --- ERROR: UnexpectedValueException [ 0 ]: Tried to check for a role that did not exist. ~ APPPATH/classes/model/user.php [ 160 ]
2012-04-02 21:32:16 --- STRACE: UnexpectedValueException [ 0 ]: Tried to check for a role that did not exist. ~ APPPATH/classes/model/user.php [ 160 ]
--
#0 /home/matt/workspace/application/classes/abstract/view/page.php(72): Model_User->is_a('verified_user')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->links()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('links', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('links')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#5 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#6 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#7 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#8 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#9 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Welcome_Index))
#10 [internal function]: Abstract_Controller_Website->after()
#11 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Welcome))
#12 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#14 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#15 {main}
2012-04-02 21:36:58 --- ERROR: Kohana_Exception [ 0 ]: The occupation property does not exist in the Model_Profile class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-02 21:36:58 --- STRACE: Kohana_Exception [ 0 ]: The occupation property does not exist in the Model_Profile class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/admin/dashboard/index.php(36): Kohana_ORM->__get('occupation')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Admin_Dashboard_Index->users()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('users', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('users')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tr>????</...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<figure id="re...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<figure id="re...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('user_table', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'user_table', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('?<h3>Admin Dash...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<h3>Admin Dash...', Array)
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<h3>Admin Dash...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#17 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#18 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Admin_Dashboard_Index))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_Dashboard))
#24 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-04-02 21:38:19 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '=', expecting ')' ~ APPPATH/classes/view/page/admin/dashboard/index.php [ 36 ]
2012-04-02 21:38:19 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '=', expecting ')' ~ APPPATH/classes/view/page/admin/dashboard/index.php [ 36 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-02 21:45:10 --- ERROR: Kohana_Exception [ 0 ]: The occupation property does not exist in the Model_Profile class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-02 21:45:10 --- STRACE: Kohana_Exception [ 0 ]: The occupation property does not exist in the Model_Profile class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/admin/user/index.php(57): Kohana_ORM->__get('occupation')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Admin_User_Index->users()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('users', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('users')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tr>????</...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<figure id="re...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<figure id="re...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('user_table', NULL, '')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'user_table', NULL, '')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('?<h3>User Admin...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<h3>User Admin...', Array)
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<h3>User Admin...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#17 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#18 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Admin_User_Index))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_User))
#24 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-04-02 21:46:03 --- ERROR: Kohana_Exception [ 0 ]: The occupation property does not exist in the Model_Profile class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-02 21:46:03 --- STRACE: Kohana_Exception [ 0 ]: The occupation property does not exist in the Model_Profile class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/admin/user/index.php(57): Kohana_ORM->__get('occupation')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Admin_User_Index->users()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('users', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('users')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tr>????</...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<figure id="re...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<figure id="re...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('user_table', NULL, '')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'user_table', NULL, '')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('?<h3>User Admin...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<h3>User Admin...', Array)
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<h3>User Admin...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#17 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#18 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Admin_User_Index))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Admin_User))
#24 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-04-02 22:21:17 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/abstract/view/page.php [ 127 ]
2012-04-02 22:21:17 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/abstract/view/page.php [ 127 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-02 22:21:28 --- ERROR: Kohana_Exception [ 0 ]: The requested route does not exist: character ~ SYSPATH/classes/kohana/route.php [ 106 ]
2012-04-02 22:21:28 --- STRACE: Kohana_Exception [ 0 ]: The requested route does not exist: character ~ SYSPATH/classes/kohana/route.php [ 106 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(192): Kohana_Route::get('character')
#1 /home/matt/workspace/application/classes/abstract/view/page.php(129): Kohana_Route::url('character', Array)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->links()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('links', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('links')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#6 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#7 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#8 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#9 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#10 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Welcome_Index))
#11 [internal function]: Abstract_Controller_Website->after()
#12 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Welcome))
#13 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#14 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#15 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#16 {main}
2012-04-02 22:21:58 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 136 ]
2012-04-02 22:21:58 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 136 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-02 22:22:22 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/character.php [ 56 ]
2012-04-02 22:22:22 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/character.php [ 56 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-02 22:25:32 --- ERROR: MustacheException [ 2 ]: Unexpected close section: #character ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
2012-04-02 22:25:32 --- STRACE: MustacheException [ 2 ]: Unexpected close section: #character ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
--
#0 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(225): Mustache->_findSection('??{{#characters...')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#characters...')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??{{^characters...', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??{{^characters...')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#9 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#10 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#12 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#13 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Character_Index))
#14 [internal function]: Abstract_Controller_Website->after()
#15 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Character))
#16 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#17 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#18 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#19 {main}