<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-04-03 12:21:56 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE, expecting '(' ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:21:56 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE, expecting '(' ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 12:23:08 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_LIST, expecting T_STRING or T_VARIABLE or '$' ~ APPPATH/classes/model/character.php [ 70 ]
2012-04-03 12:23:08 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_LIST, expecting T_STRING or T_VARIABLE or '$' ~ APPPATH/classes/model/character.php [ 70 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 12:24:09 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
2012-04-03 12:24:09 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:24:39 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/model/character.php [ 43 ]
2012-04-03 12:24:39 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/model/character.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:24:55 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
2012-04-03 12:24:55 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:25:38 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:25:38 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:26:02 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:26:02 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:27:07 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:27:07 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:27:50 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:27:50 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:28:18 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:28:18 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:28:22 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:28:22 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:28:55 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
2012-04-03 12:28:55 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:29:55 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
2012-04-03 12:29:55 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:30:09 --- ERROR: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
2012-04-03 12:30:09 --- STRACE: ErrorException [ 8 ]: Undefined index: profession ~ APPPATH/classes/model/character.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/model/character.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:30:24 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Valid::regex() ~ SYSPATH/classes/kohana/valid.php [ 37 ]
2012-04-03 12:30:24 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Valid::regex() ~ SYSPATH/classes/kohana/valid.php [ 37 ]
--
#0 /home/matt/workspace/system/classes/kohana/valid.php(37): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/work...', 37, Array)
#1 [internal function]: Kohana_Valid::regex('^[a-zA-Z]+( [a-...')
#2 /home/matt/workspace/system/classes/kohana/validation.php(378): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1172): Kohana_Validation->check()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1200): Kohana_ORM->check(NULL)
#5 /home/matt/workspace/application/classes/model/character.php(48): Kohana_ORM->create()
#6 /home/matt/workspace/application/classes/controller/character.php(54): Model_Character->create_character(Object(Model_User), Array, Array)
#7 [internal function]: Controller_Character->action_add()
#8 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#9 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-04-03 12:31:33 --- ERROR: ErrorException [ 2 ]: preg_match(): No ending delimiter '^' found ~ SYSPATH/classes/kohana/valid.php [ 39 ]
2012-04-03 12:31:33 --- STRACE: ErrorException [ 2 ]: preg_match(): No ending delimiter '^' found ~ SYSPATH/classes/kohana/valid.php [ 39 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): N...', '/home/matt/work...', 39, Array)
#1 /home/matt/workspace/system/classes/kohana/valid.php(39): preg_match('^[a-zA-Z]+( [a-...', 'testwar')
#2 [internal function]: Kohana_Valid::regex('testwar', '^[a-zA-Z]+( [a-...')
#3 /home/matt/workspace/system/classes/kohana/validation.php(378): ReflectionMethod->invokeArgs(NULL, Array)
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1172): Kohana_Validation->check()
#5 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1200): Kohana_ORM->check(NULL)
#6 /home/matt/workspace/application/classes/model/character.php(48): Kohana_ORM->create()
#7 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#8 [internal function]: Controller_Character->action_add()
#9 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#10 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-04-03 12:33:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `character`.* FROM `characters` AS `character` WHERE 0 = 'name' AND `1` = 'testwar' LIMIT 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-04-03 12:33:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `character`.* FROM `characters` AS `character` WHERE 0 = 'name' AND `1` = 'testwar' LIMIT 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `charact...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(898): Kohana_ORM->_load_result(false)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(258): Kohana_ORM->find()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#5 /home/matt/workspace/application/classes/model/character.php(59): Kohana_ORM::factory('character', Array)
#6 [internal function]: Model_Character->character_name_available('testwar')
#7 /home/matt/workspace/system/classes/kohana/validation.php(364): call_user_func_array(Array, Array)
#8 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1172): Kohana_Validation->check()
#9 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1200): Kohana_ORM->check(NULL)
#10 /home/matt/workspace/application/classes/model/character.php(48): Kohana_ORM->create()
#11 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#12 [internal function]: Controller_Character->action_add()
#13 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#14 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#16 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#17 {main}
2012-04-03 12:37:48 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `character`.* FROM `characters` AS `character` WHERE 0 = 'name' AND `1` = 'testwar' LIMIT 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-04-03 12:37:48 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `character`.* FROM `characters` AS `character` WHERE 0 = 'name' AND `1` = 'testwar' LIMIT 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `charact...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(898): Kohana_ORM->_load_result(false)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(258): Kohana_ORM->find()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#5 /home/matt/workspace/application/classes/model/character.php(62): Kohana_ORM::factory('character', Array)
#6 [internal function]: Model_Character->character_name_available('testwar')
#7 /home/matt/workspace/system/classes/kohana/validation.php(364): call_user_func_array(Array, Array)
#8 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1172): Kohana_Validation->check()
#9 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1200): Kohana_ORM->check(NULL)
#10 /home/matt/workspace/application/classes/model/character.php(48): Kohana_ORM->create()
#11 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#12 [internal function]: Controller_Character->action_add()
#13 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#14 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#16 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#17 {main}
2012-04-03 12:39:37 --- ERROR: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH/orm/classes/kohana/orm.php [ 1174 ]
2012-04-03 12:39:37 --- STRACE: ORM_Validation_Exception [ 0 ]: Failed to validate array ~ MODPATH/orm/classes/kohana/orm.php [ 1174 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1200): Kohana_ORM->check(NULL)
#1 /home/matt/workspace/application/classes/model/character.php(48): Kohana_ORM->create()
#2 /home/matt/workspace/application/classes/controller/character.php(52): Model_Character->create_character(Object(Model_User), Array, Array)
#3 [internal function]: Controller_Character->action_add()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-03 12:45:14 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:45:14 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:45:52 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:45:52 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:47:00 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:47:00 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:47:06 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:47:06 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:48:15 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:48:15 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:50:06 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:50:06 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:51:14 --- ERROR: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
2012-04-03 12:51:14 --- STRACE: Kohana_Exception [ 0 ]: Required route parameter not passed: id ~ SYSPATH/classes/kohana/route.php [ 518 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(198): Kohana_Route->uri(NULL)
#1 /home/matt/workspace/application/classes/controller/character.php(63): Kohana_Route::url('character displ...')
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-03 12:58:45 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/character.php [ 58 ]
2012-04-03 12:58:45 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/character.php [ 58 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 12:59:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/5 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 12:59:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/5 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 12:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/6 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 12:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/6 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 13:00:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/7 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 13:00:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/7 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 17:59:56 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Exception::errors() ~ APPPATH/classes/controller/character.php [ 62 ]
2012-04-03 17:59:56 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Exception::errors() ~ APPPATH/classes/controller/character.php [ 62 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:01:54 --- ERROR: ErrorException [ 1 ]: Cannot access protected property Database_Exception::$message ~ APPPATH/classes/controller/character.php [ 62 ]
2012-04-03 18:01:54 --- STRACE: ErrorException [ 1 ]: Cannot access protected property Database_Exception::$message ~ APPPATH/classes/controller/character.php [ 62 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:02:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Exception::errors() ~ APPPATH/classes/controller/character.php [ 63 ]
2012-04-03 18:02:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Exception::errors() ~ APPPATH/classes/controller/character.php [ 63 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:02:19 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Exception::errors() ~ APPPATH/classes/controller/character.php [ 64 ]
2012-04-03 18:02:19 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Exception::errors() ~ APPPATH/classes/controller/character.php [ 64 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:03:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/5 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 18:03:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/5 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 18:06:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/6 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 18:06:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/6 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 18:06:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/7 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 18:06:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/7 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 18:07:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 18:07:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 18:11:30 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/policy/character/add.php [ 14 ]
2012-04-03 18:11:30 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/policy/character/add.php [ 14 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:11:53 --- ERROR: ErrorException [ 1 ]: Class 'Policy_Add_Character' not found ~ APPPATH/classes/controller/character.php [ 23 ]
2012-04-03 18:11:53 --- STRACE: ErrorException [ 1 ]: Class 'Policy_Add_Character' not found ~ APPPATH/classes/controller/character.php [ 23 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:16:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 18:16:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 18:22:02 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: missing ) at offset 63 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-04-03 18:22:02 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: missing ) at offset 63 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/home/matt/work...', 392, Array)
#1 /home/matt/workspace/system/classes/kohana/route.php(392): preg_match('#^character(?:/...', 'character/1', NULL)
#2 /home/matt/workspace/system/classes/kohana/request.php(567): Kohana_Route->matches('character/1')
#3 /home/matt/workspace/system/classes/kohana/request.php(785): Kohana_Request::process_uri('character/1', Array)
#4 /home/matt/workspace/system/classes/kohana/request.php(198): Kohana_Request->__construct('/character/1', NULL)
#5 /home/matt/workspace/public_html/index.php(108): Kohana_Request::factory()
#6 {main}
2012-04-03 18:22:23 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/character.php [ 58 ]
2012-04-03 18:22:23 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/character.php [ 58 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:22:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-03 18:22:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-03 18:39:18 --- ERROR: Kohana_Exception [ 0 ]: The profession property does not exist in the Model_Character class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-03 18:39:18 --- STRACE: Kohana_Exception [ 0 ]: The profession property does not exist in the Model_Character class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/character/index.php(19): Kohana_ORM->__get('profession')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Character_Index->character_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('character_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('character_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#character_...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#characters...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??{{^characters...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??{{^characters...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Character_Index))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Character))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-04-03 18:39:22 --- ERROR: Kohana_Exception [ 0 ]: The profession property does not exist in the Model_Character class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-03 18:39:22 --- STRACE: Kohana_Exception [ 0 ]: The profession property does not exist in the Model_Character class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/character/index.php(19): Kohana_ORM->__get('profession')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Character_Index->character_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('character_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('character_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#character_...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#characters...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??{{^characters...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??{{^characters...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Character_Index))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Character))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-04-03 18:54:34 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/email/classes/kohana/email.php [ 31 ]
2012-04-03 18:54:34 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/email/classes/kohana/email.php [ 31 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-03 18:57:22 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/view/page/character/index.php [ 17 ]
2012-04-03 18:57:22 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/view/page/character/index.php [ 17 ]
--
#0 /home/matt/workspace/application/classes/view/page/character/index.php(17): Kohana_Core::error_handler(2, 'Invalid argumen...', '/home/matt/work...', 17, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Character_Index->character_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('character_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('character_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#character_...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{#count}}???...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??{{^count}}<p>...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??{{^count}}<p>...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Character_Index))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Character))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}