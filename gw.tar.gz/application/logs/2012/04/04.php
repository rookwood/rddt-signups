<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-04-04 16:54:43 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '}', expecting '(' ~ APPPATH/classes/controller/character.php [ 93 ]
2012-04-04 16:54:43 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '}', expecting '(' ~ APPPATH/classes/controller/character.php [ 93 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 16:56:50 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 135 ]
2012-04-04 16:56:50 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 135 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 16:57:13 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 135 ]
2012-04-04 16:57:13 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 135 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 16:59:43 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 135 ]
2012-04-04 16:59:43 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_NEW ~ APPPATH/classes/controller/event.php [ 135 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 17:00:11 --- ERROR: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
2012-04-04 17:00:11 --- STRACE: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 17:00:27 --- ERROR: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
2012-04-04 17:00:27 --- STRACE: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 17:01:44 --- ERROR: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
2012-04-04 17:01:44 --- STRACE: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 17:05:18 --- ERROR: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
2012-04-04 17:05:18 --- STRACE: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 17:05:18 --- ERROR: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
2012-04-04 17:05:18 --- STRACE: ErrorException [ 1 ]: Call to undefined method Swift_DependencyContainer::getInstance() ~ MODPATH/email/vendor/swiftmailer/lib/dependency_maps/cache_deps.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 17:08:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL character' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-04-04 17:08:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL character' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-04 17:08:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/classes/view/page/user/manage.php [ 22 ]
2012-04-04 17:08:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/classes/view/page/user/manage.php [ 22 ]
--
#0 /home/matt/workspace/application/classes/view/page/user/manage.php(22): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 22, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_User_Manage->timezone_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(254): Mustache->_renderTemplate('??????<li>?????...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(254): Mustache->_renderTemplate('<li>???????<lab...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????<fieldset>?...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????{{#success}...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#16 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#17 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#18 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#19 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_User_Manage))
#20 [internal function]: Abstract_Controller_Website->after()
#21 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_User))
#22 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#23 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#24 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#25 {main}
2012-04-04 17:43:18 --- ERROR: ErrorException [ 2 ]: preg_match(): No ending delimiter '^' found ~ SYSPATH/classes/kohana/valid.php [ 39 ]
2012-04-04 17:43:18 --- STRACE: ErrorException [ 2 ]: preg_match(): No ending delimiter '^' found ~ SYSPATH/classes/kohana/valid.php [ 39 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): N...', '/home/matt/work...', 39, Array)
#1 /home/matt/workspace/system/classes/kohana/valid.php(39): preg_match('^[a-zA-Z]+( [a-...', 'asdfqwer')
#2 [internal function]: Kohana_Valid::regex('asdfqwer', '^[a-zA-Z]+( [a-...')
#3 /home/matt/workspace/system/classes/kohana/validation.php(378): ReflectionMethod->invokeArgs(NULL, Array)
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1172): Kohana_Validation->check()
#5 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1200): Kohana_ORM->check(NULL)
#6 /home/matt/workspace/application/classes/model/character.php(54): Kohana_ORM->create()
#7 /home/matt/workspace/application/classes/controller/character.php(59): Model_Character->create_character(Object(Model_User), Array, Array)
#8 [internal function]: Controller_Character->action_add()
#9 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Character))
#10 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-04-04 17:59:40 --- ERROR: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/index.php [ 9 ]
2012-04-04 17:59:40 --- STRACE: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/index.php [ 9 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(9): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 9, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-04 18:00:58 --- ERROR: Kohana_Exception [ 0 ]: The user property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-04 18:00:58 --- STRACE: Kohana_Exception [ 0 ]: The user property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(19): Kohana_ORM->__get('user')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-04 18:01:44 --- ERROR: Kohana_Exception [ 0 ]: The name property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-04 18:01:44 --- STRACE: Kohana_Exception [ 0 ]: The name property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(19): Kohana_ORM->__get('name')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-04 19:20:06 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/view/page/event/index.php [ 10 ]
2012-04-04 19:20:06 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/view/page/event/index.php [ 10 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 19:20:18 --- ERROR: Exception [ 0 ]: DateTime::__construct(): Failed to parse time string (1333843200) at position 8 (0): Unexpected character ~ SYSPATH/classes/kohana/date.php [ 593 ]
2012-04-04 19:20:18 --- STRACE: Exception [ 0 ]: DateTime::__construct(): Failed to parse time string (1333843200) at position 8 (0): Unexpected character ~ SYSPATH/classes/kohana/date.php [ 593 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(593): DateTime->__construct('1333843200', Object(DateTimeZone))
#1 /home/matt/workspace/application/classes/view/page/event/index.php(10): Kohana_Date::formatted_time(1333843200)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:20:37 --- ERROR: Exception [ 0 ]: DateTime::__construct(): Failed to parse time string (1333843200) at position 8 (0): Unexpected character ~ SYSPATH/classes/kohana/date.php [ 593 ]
2012-04-04 19:20:37 --- STRACE: Exception [ 0 ]: DateTime::__construct(): Failed to parse time string (1333843200) at position 8 (0): Unexpected character ~ SYSPATH/classes/kohana/date.php [ 593 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(593): DateTime->__construct('1333843200', Object(DateTimeZone))
#1 /home/matt/workspace/application/classes/view/page/event/index.php(10): Kohana_Date::formatted_time('1333843200')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:21:25 --- ERROR: Exception [ 0 ]: DateTime::__construct(): Failed to parse time string (2012-Apr-Sat) at position 8 (-): Unexpected character ~ SYSPATH/classes/kohana/date.php [ 593 ]
2012-04-04 19:21:25 --- STRACE: Exception [ 0 ]: DateTime::__construct(): Failed to parse time string (2012-Apr-Sat) at position 8 (-): Unexpected character ~ SYSPATH/classes/kohana/date.php [ 593 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(593): DateTime->__construct('2012-Apr-Sat', Object(DateTimeZone))
#1 /home/matt/workspace/application/classes/view/page/event/index.php(10): Kohana_Date::formatted_time('2012-Apr-Sat')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:30:59 --- ERROR: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
2012-04-04 19:30:59 --- STRACE: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(67): DateTimeZone->__construct('')
#1 /home/matt/workspace/application/classes/view/page/event/index.php(12): Kohana_Date::offset('', 'GMT', 1333843200)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:31:27 --- ERROR: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
2012-04-04 19:31:27 --- STRACE: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(67): DateTimeZone->__construct('')
#1 /home/matt/workspace/application/classes/view/page/event/index.php(12): Kohana_Date::offset('', 'Europe/London', 1333843200)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:31:33 --- ERROR: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
2012-04-04 19:31:33 --- STRACE: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(67): DateTimeZone->__construct('')
#1 /home/matt/workspace/application/classes/view/page/event/index.php(12): Kohana_Date::offset('', 'Europe/London', 1333843200)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:33:36 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/view/page/event/index.php [ 13 ]
2012-04-04 19:33:36 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/view/page/event/index.php [ 13 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-04 19:39:45 --- ERROR: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
2012-04-04 19:39:45 --- STRACE: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone () ~ SYSPATH/classes/kohana/date.php [ 67 ]
--
#0 /home/matt/workspace/system/classes/kohana/date.php(67): DateTimeZone->__construct('')
#1 /home/matt/workspace/application/classes/view/page/event/index.php(12): Kohana_Date::offset('', 'Europe/London')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:45:07 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Kohana_ProfilerToolbar::addData(), called in /home/matt/workspace/application/classes/view/page/event/index.php on line 11 and defined ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 400 ]
2012-04-04 19:45:07 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Kohana_ProfilerToolbar::addData(), called in /home/matt/workspace/application/classes/view/page/event/index.php on line 11 and defined ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 400 ]
--
#0 /home/matt/workspace/modules/profilertoolbar/classes/kohana/profilertoolbar.php(400): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/work...', 400, Array)
#1 /home/matt/workspace/application/classes/view/page/event/index.php(11): Kohana_ProfilerToolbar::addData()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:45:23 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Kohana_ProfilerToolbar::addData(), called in /home/matt/workspace/application/classes/view/page/event/index.php on line 11 and defined ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 400 ]
2012-04-04 19:45:23 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Kohana_ProfilerToolbar::addData(), called in /home/matt/workspace/application/classes/view/page/event/index.php on line 11 and defined ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 400 ]
--
#0 /home/matt/workspace/modules/profilertoolbar/classes/kohana/profilertoolbar.php(400): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/work...', 400, Array)
#1 /home/matt/workspace/application/classes/view/page/event/index.php(11): Kohana_ProfilerToolbar::addData()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-04 19:45:44 --- ERROR: Kohana_Exception [ 0 ]: The timezeone property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-04 19:45:44 --- STRACE: Kohana_Exception [ 0 ]: The timezeone property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(12): Kohana_ORM->__get('timezeone')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-04 19:52:49 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 131 ]
2012-04-04 19:52:49 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 131 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(131): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 131, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-04 21:36:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL event/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-04 21:36:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL event/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-04 21:48:36 --- ERROR: Database_Exception [ 1146 ]: Table 'gw.statuses' doesn't exist [ SHOW FULL COLUMNS FROM `statuses` ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-04 21:48:36 --- STRACE: Database_Exception [ 1146 ]: Table 'gw.statuses' doesn't exist [ SHOW FULL COLUMNS FROM `statuses` ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/profilertoolbar/classes/kohana/database/mysql.php(398): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1504): Kohana_Database_MySQL->list_columns('statuses')
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns(true)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /home/matt/workspace/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1525): Kohana_ORM::factory('status')
#7 /home/matt/workspace/modules/orm/classes/kohana/orm.php(560): Kohana_ORM->_related('status')
#8 /home/matt/workspace/application/classes/view/page/event/index.php(23): Kohana_ORM->__get('status')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#17 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#18 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#19 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#20 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#21 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#22 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#23 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#24 [internal function]: Abstract_Controller_Website->after()
#25 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#26 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#27 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#28 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#29 {main}
2012-04-04 21:52:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL event/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-04-04 21:52:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL event/1 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}