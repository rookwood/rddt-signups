<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-04-05 16:37:50 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
2012-04-05 16:37:50 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(28): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 28, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-05 16:37:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
2012-04-05 16:37:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(28): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 28, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-05 16:37:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
2012-04-05 16:37:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(28): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 28, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-05 16:40:34 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
2012-04-05 16:40:34 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/index.php [ 28 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(28): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 28, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-05 16:41:10 --- ERROR: MustacheException [ 2 ]: Unexpected close section: errors.select ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
2012-04-05 16:41:10 --- STRACE: MustacheException [ 2 ]: Unexpected close section: errors.select ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
--
#0 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(225): Mustache->_findSection('???????</select...')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#dungeon_l...')
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<form action...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<form action...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Add))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-05 16:42:17 --- ERROR: MustacheException [ 2 ]: Unexpected close section: errors.time ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
2012-04-05 16:42:17 --- STRACE: MustacheException [ 2 ]: Unexpected close section: errors.time ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
--
#0 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(225): Mustache->_findSection('??????</li>????...')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>??????</li>??...')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#dungeon_l...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<form action...', Array)
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<form action...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#16 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#17 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#18 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#19 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#20 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Add))
#21 [internal function]: Abstract_Controller_Website->after()
#22 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#23 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#24 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#25 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#26 {main}
2012-04-05 17:03:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: values ~ APPPATH/classes/view/page/event/add.php [ 43 ]
2012-04-05 17:03:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: values ~ APPPATH/classes/view/page/event/add.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/add.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Add->dungeon_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('dungeon_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('dungeon_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#dungeon_l...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<form action...', Array)
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<form action...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#15 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#16 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#17 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#18 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Add))
#19 [internal function]: Abstract_Controller_Website->after()
#20 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#21 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#22 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#23 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#24 {main}
2012-04-05 17:03:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: values ~ APPPATH/classes/view/page/event/add.php [ 43 ]
2012-04-05 17:03:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: values ~ APPPATH/classes/view/page/event/add.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/add.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Add->dungeon_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('dungeon_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('dungeon_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#dungeon_l...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<form action...', Array)
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<form action...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#15 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#16 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#17 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#18 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Add))
#19 [internal function]: Abstract_Controller_Website->after()
#20 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#21 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#22 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#23 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#24 {main}
2012-04-05 17:05:23 --- ERROR: ErrorException [ 8 ]: Undefined index: ampm ~ APPPATH/classes/model/event.php [ 27 ]
2012-04-05 17:05:23 --- STRACE: ErrorException [ 8 ]: Undefined index: ampm ~ APPPATH/classes/model/event.php [ 27 ]
--
#0 /home/matt/workspace/application/classes/model/event.php(27): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 27, Array)
#1 /home/matt/workspace/application/classes/controller/event.php(54): Model_Event->create_event(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Event->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-05 17:06:12 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `dungeon`.* FROM `dungeons` AS `dungeon` WHERE 0 = 'name' AND `1` = 'Domain of Anguish' LIMIT 1 ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 17:06:12 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `dungeon`.* FROM `dungeons` AS `dungeon` WHERE 0 = 'name' AND `1` = 'Domain of Anguish' LIMIT 1 ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `dungeon...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(898): Kohana_ORM->_load_result(false)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(258): Kohana_ORM->find()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#5 /home/matt/workspace/application/classes/model/event.php(34): Kohana_ORM::factory('dungeon', Array)
#6 /home/matt/workspace/application/classes/controller/event.php(54): Model_Event->create_event(Object(Model_User), Array, Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-04-05 17:11:23 --- ERROR: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/model/event.php [ 38 ]
2012-04-05 17:11:23 --- STRACE: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/model/event.php [ 38 ]
--
#0 /home/matt/workspace/application/classes/model/event.php(38): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 38, Array)
#1 /home/matt/workspace/application/classes/controller/event.php(54): Model_Event->create_event(Object(Model_User), Array, Array)
#2 [internal function]: Controller_Event->action_add()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-05 17:13:05 --- ERROR: Kohana_Exception [ 0 ]: The date property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 681 ]
2012-04-05 17:13:05 --- STRACE: Kohana_Exception [ 0 ]: The date property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 681 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(634): Kohana_ORM->set('date', '2012-04-06')
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(725): Kohana_ORM->__set('date', '2012-04-06')
#2 /home/matt/workspace/application/classes/model/event.php(54): Kohana_ORM->values(Array, Array)
#3 /home/matt/workspace/application/classes/controller/event.php(54): Model_Event->create_event(Object(Model_User), Array, Array)
#4 [internal function]: Controller_Event->action_add()
#5 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#6 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-04-05 17:16:39 --- ERROR: Kohana_Exception [ 0 ]: The timezone property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 681 ]
2012-04-05 17:16:39 --- STRACE: Kohana_Exception [ 0 ]: The timezone property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 681 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(634): Kohana_ORM->set('timezone', 'America/Chicago')
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(725): Kohana_ORM->__set('timezone', 'America/Chicago')
#2 /home/matt/workspace/application/classes/model/event.php(54): Kohana_ORM->values(Array, Array)
#3 /home/matt/workspace/application/classes/controller/event.php(54): Model_Event->create_event(Object(Model_User), Array, Array)
#4 [internal function]: Controller_Event->action_add()
#5 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#6 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-04-05 17:18:01 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/classes/model/event.php [ 50 ]
2012-04-05 17:18:01 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/classes/model/event.php [ 50 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:18:43 --- ERROR: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
2012-04-05 17:18:43 --- STRACE: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:18:59 --- ERROR: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
2012-04-05 17:18:59 --- STRACE: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:20:42 --- ERROR: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
2012-04-05 17:20:42 --- STRACE: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:21:48 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ',' or ')' ~ APPPATH/classes/model/event.php [ 52 ]
2012-04-05 17:21:48 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ',' or ')' ~ APPPATH/classes/model/event.php [ 52 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:22:07 --- ERROR: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
2012-04-05 17:22:07 --- STRACE: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:22:40 --- ERROR: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
2012-04-05 17:22:40 --- STRACE: ErrorException [ 1 ]: Call to a member function pk() on a non-object ~ MODPATH/orm/classes/kohana/orm.php [ 675 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 17:25:01 --- ERROR: Kohana_Exception [ 0 ]: The requested route does not exist: event display ~ SYSPATH/classes/kohana/route.php [ 106 ]
2012-04-05 17:25:01 --- STRACE: Kohana_Exception [ 0 ]: The requested route does not exist: event display ~ SYSPATH/classes/kohana/route.php [ 106 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(192): Kohana_Route::get('event display')
#1 /home/matt/workspace/application/classes/view/page/event/index.php(19): Kohana_Route::url('event display', Array)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-05 17:25:54 --- ERROR: Kohana_Exception [ 0 ]: The requested route does not exist: event display ~ SYSPATH/classes/kohana/route.php [ 106 ]
2012-04-05 17:25:54 --- STRACE: Kohana_Exception [ 0 ]: The requested route does not exist: event display ~ SYSPATH/classes/kohana/route.php [ 106 ]
--
#0 /home/matt/workspace/system/classes/kohana/route.php(192): Kohana_Route::get('event display')
#1 /home/matt/workspace/application/classes/view/page/event/index.php(19): Kohana_Route::url('event display', Array)
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-05 18:44:53 --- ERROR: Kohana_Exception [ 0 ]: The characters property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-05 18:44:53 --- STRACE: Kohana_Exception [ 0 ]: The characters property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/display.php(38): Kohana_ORM->__get('characters')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->characters()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('characters', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('characters')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-05 18:46:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL events was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-04-05 18:46:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL events was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-05 18:46:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL events was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-04-05 18:46:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL events was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-05 18:46:55 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 144 ]
2012-04-05 18:46:55 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 144 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(144): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 144, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:48:31 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 146 ]
2012-04-05 18:48:31 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 146 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(146): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 146, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:48:55 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 147 ]
2012-04-05 18:48:55 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/controller/event.php [ 147 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(147): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 147, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:49:31 --- ERROR: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 147 ]
2012-04-05 18:49:31 --- STRACE: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 147 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(147): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 147, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:50:26 --- ERROR: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 147 ]
2012-04-05 18:50:26 --- STRACE: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 147 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(147): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 147, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:50:37 --- ERROR: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 147 ]
2012-04-05 18:50:37 --- STRACE: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 147 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(147): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 147, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:50:59 --- ERROR: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 145 ]
2012-04-05 18:50:59 --- STRACE: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 145 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(145): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 145, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:51:29 --- ERROR: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 145 ]
2012-04-05 18:51:29 --- STRACE: ErrorException [ 8 ]: Undefined index: character ~ APPPATH/classes/controller/event.php [ 145 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(145): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 145, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:51:37 --- ERROR: ErrorException [ 8 ]: Undefined index: character ~ MODPATH/orm/classes/kohana/orm.php [ 1403 ]
2012-04-05 18:51:37 --- STRACE: ErrorException [ 8 ]: Undefined index: character ~ MODPATH/orm/classes/kohana/orm.php [ 1403 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1403): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 1403, Array)
#1 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('character', Object(Model_Character))
#2 [internal function]: Controller_Event->action_signup()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-05 18:55:34 --- ERROR: ErrorException [ 1 ]: Class 'Model_Signup' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2012-04-05 18:55:34 --- STRACE: ErrorException [ 1 ]: Class 'Model_Signup' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-05 18:56:11 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '6-8' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '8') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 18:56:11 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '6-8' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '8') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-05 18:56:20 --- ERROR: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/controller/event.php [ 157 ]
2012-04-05 18:56:20 --- STRACE: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/controller/event.php [ 157 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(157): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 157, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 18:57:25 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '6-7' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '7') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 18:57:25 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '6-7' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '7') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-05 18:57:42 --- ERROR: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/controller/event.php [ 157 ]
2012-04-05 18:57:42 --- STRACE: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/controller/event.php [ 157 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(157): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 157, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 19:11:57 --- ERROR: Kohana_Exception [ 0 ]: The status_id property does not exist in the Model_Signup class ~ MODPATH/orm/classes/kohana/orm.php [ 681 ]
2012-04-05 19:11:57 --- STRACE: Kohana_Exception [ 0 ]: The status_id property does not exist in the Model_Signup class ~ MODPATH/orm/classes/kohana/orm.php [ 681 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(634): Kohana_ORM->set('status_id', '4')
#1 /home/matt/workspace/application/classes/controller/event.php(165): Kohana_ORM->__set('status_id', '4')
#2 [internal function]: Controller_Event->action_signup()
#3 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-04-05 19:14:10 --- ERROR: ErrorException [ 8 ]: Undefined index: comment ~ APPPATH/classes/controller/event.php [ 168 ]
2012-04-05 19:14:10 --- STRACE: ErrorException [ 8 ]: Undefined index: comment ~ APPPATH/classes/controller/event.php [ 168 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(168): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 168, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 19:20:12 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '6-9' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '9') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 19:20:12 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '6-9' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '9') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-05 19:20:28 --- ERROR: ErrorException [ 8 ]: Undefined index: comment ~ APPPATH/classes/controller/event.php [ 168 ]
2012-04-05 19:20:28 --- STRACE: ErrorException [ 8 ]: Undefined index: comment ~ APPPATH/classes/controller/event.php [ 168 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(168): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 168, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 19:26:08 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '6-9' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '9') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 19:26:08 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '6-9' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '9') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-05 19:26:24 --- ERROR: ErrorException [ 8 ]: Undefined index: comment ~ APPPATH/classes/controller/event.php [ 168 ]
2012-04-05 19:26:24 --- STRACE: ErrorException [ 8 ]: Undefined index: comment ~ APPPATH/classes/controller/event.php [ 168 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(168): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 168, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-05 19:36:00 --- ERROR: Exception [ 0 ]: failed to find signup record ~ APPPATH/classes/controller/event.php [ 157 ]
2012-04-05 19:36:00 --- STRACE: Exception [ 0 ]: failed to find signup record ~ APPPATH/classes/controller/event.php [ 157 ]
--
#0 [internal function]: Controller_Event->action_signup()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-05 19:37:19 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '6-1' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '1') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 19:37:19 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '6-1' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '1') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-05 19:37:52 --- ERROR: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 161 ]
2012-04-05 19:37:52 --- STRACE: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 161 ]
--
#0 [internal function]: Controller_Event->action_signup()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-05 19:41:41 --- ERROR: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 165 ]
2012-04-05 19:41:41 --- STRACE: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 165 ]
--
#0 [internal function]: Controller_Event->action_signup()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-05 20:00:51 --- ERROR: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 165 ]
2012-04-05 20:00:51 --- STRACE: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 165 ]
--
#0 [internal function]: Controller_Event->action_signup()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-05 20:01:20 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '6-2' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '2') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-05 20:01:20 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '6-2' for key 'PRIMARY' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('6', '2') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(151): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-05 20:01:29 --- ERROR: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 166 ]
2012-04-05 20:01:29 --- STRACE: Exception [ 0 ]: failed to load signup record ~ APPPATH/classes/controller/event.php [ 166 ]
--
#0 [internal function]: Controller_Event->action_signup()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-05 20:05:16 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Signup::load() ~ APPPATH/classes/controller/event.php [ 160 ]
2012-04-05 20:05:16 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Signup::load() ~ APPPATH/classes/controller/event.php [ 160 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}