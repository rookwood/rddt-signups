<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-04-06 09:44:00 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Signup::load() ~ APPPATH/classes/controller/event.php [ 160 ]
2012-04-06 09:44:00 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Signup::load() ~ APPPATH/classes/controller/event.php [ 160 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-06 10:49:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL events was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-04-06 10:49:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL events was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-04-06 10:49:24 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Signup::load() ~ APPPATH/classes/controller/event.php [ 160 ]
2012-04-06 10:49:24 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Signup::load() ~ APPPATH/classes/controller/event.php [ 160 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-06 14:00:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/display.php [ 43 ]
2012-04-06 14:00:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/display.php [ 43 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/display.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 43, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->attendees()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('attendees', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('attendees')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????</select>?...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-04-06 14:16:41 --- ERROR: MustacheException [ 2 ]: Unexpected close section: errors.build ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
2012-04-06 14:16:41 --- STRACE: MustacheException [ 2 ]: Unexpected close section: errors.build ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
--
#0 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(225): Mustache->_findSection('/>??????</li>??...')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>??????</li>??...')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('></textarea>???...')
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>??????</li>??...')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>??????</li>??...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#dungeon_l...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<form action...', Array)
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<form action...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#17 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#18 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#19 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#20 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#21 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#22 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#23 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Add))
#24 [internal function]: Abstract_Controller_Website->after()
#25 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#26 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#27 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#28 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#29 {main}
2012-04-06 14:53:03 --- ERROR: ErrorException [ 2 ]: file_get_contents(/home/matt/workspace/application/templates/page/event/edit.mustache): failed to open stream: Permission denied ~ MODPATH/kostache/classes/kohana/kostache.php [ 249 ]
2012-04-06 14:53:03 --- STRACE: ErrorException [ 2 ]: file_get_contents(/home/matt/workspace/application/templates/page/event/edit.mustache): failed to open stream: Permission denied ~ MODPATH/kostache/classes/kohana/kostache.php [ 249 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'file_get_conten...', '/home/matt/work...', 249, Array)
#1 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(249): file_get_contents('/home/matt/work...')
#2 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(127): Kohana_Kostache->_load('page/event/edit')
#3 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(76): Kohana_Kostache->template('page/event/edit')
#4 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(37): Kohana_Kostache->__construct(NULL, NULL)
#5 /home/matt/workspace/application/classes/abstract/controller/website.php(44): Kohana_Kostache::factory('page/event/edit')
#6 [internal function]: Abstract_Controller_Website->before()
#7 /home/matt/workspace/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Event))
#8 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#10 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#11 {main}
2012-04-06 14:55:09 --- ERROR: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/edit.php [ 13 ]
2012-04-06 14:55:09 --- STRACE: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/edit.php [ 13 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/edit.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 13, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Edit->event_edit_action()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('event_edit_acti...', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(655): Mustache->_getVariable('event_edit_acti...')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(622): Mustache->_renderUnescaped('event_edit_acti...', '', '')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(590): Mustache->_renderEscaped('event_edit_acti...', NULL, NULL)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('', 'event_edit_acti...', NULL, NULL)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??<form action=...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??<form action=...', Array)
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??<form action=...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#16 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#17 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#18 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#19 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Edit))
#20 [internal function]: Abstract_Controller_Website->after()
#21 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#22 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#23 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#24 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#25 {main}
2012-04-06 14:56:48 --- ERROR: ErrorException [ 8 ]: Undefined index: dungeon ~ APPPATH/classes/view/page/event/edit.php [ 45 ]
2012-04-06 14:56:48 --- STRACE: ErrorException [ 8 ]: Undefined index: dungeon ~ APPPATH/classes/view/page/event/edit.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/edit.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Edit->dungeon_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('dungeon_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('dungeon_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>?{{#dungeon_li...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</li>?????<...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>??????{{#erro...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??<form action=...', Array)
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??<form action=...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#15 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#16 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#17 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#18 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Edit))
#19 [internal function]: Abstract_Controller_Website->after()
#20 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#21 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#22 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#23 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#24 {main}
2012-04-06 15:01:08 --- ERROR: ErrorException [ 8 ]: Undefined index: dungeon ~ APPPATH/classes/view/page/event/edit.php [ 45 ]
2012-04-06 15:01:08 --- STRACE: ErrorException [ 8 ]: Undefined index: dungeon ~ APPPATH/classes/view/page/event/edit.php [ 45 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/edit.php(45): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 45, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Edit->dungeon_list()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('dungeon_list', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('dungeon_list')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>?{{#dungeon_li...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</li>?????<...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>??????{{#erro...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('??<form action=...', Array)
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('??<form action=...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#15 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#16 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#17 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#18 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Edit))
#19 [internal function]: Abstract_Controller_Website->after()
#20 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#21 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#22 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#23 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#24 {main}
2012-04-06 15:12:12 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/view/page/event/display.php [ 66 ]
2012-04-06 15:12:12 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/view/page/event/display.php [ 66 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-06 15:12:30 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/view/page/event/display.php [ 67 ]
2012-04-06 15:12:30 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/view/page/event/display.php [ 67 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-06 15:19:31 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Event::andwhere() ~ APPPATH/classes/controller/event.php [ 12 ]
2012-04-06 15:19:31 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Event::andwhere() ~ APPPATH/classes/controller/event.php [ 12 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-06 15:19:40 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'status' in 'where clause' [ SELECT `event`.* FROM `events` AS `event` WHERE `time` > '1333739980' AND `status` != '2' ORDER BY `time` ASC ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-06 15:19:40 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'status' in 'where clause' [ SELECT `event`.* FROM `events` AS `event` WHERE `time` > '1333739980' AND `status` != '2' ORDER BY `time` ASC ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `event`....', 'Model_Event', Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(963): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(922): Kohana_ORM->_load_result(true)
#3 /home/matt/workspace/application/classes/controller/event.php(14): Kohana_ORM->find_all()
#4 [internal function]: Controller_Event->action_index()
#5 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#6 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-04-06 15:43:18 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Policy_Event_Remove::execute() must be an array, object given, called in /home/matt/workspace/application/classes/model/user.php on line 41 and defined ~ APPPATH/classes/policy/event/remove.php [ 5 ]
2012-04-06 15:43:18 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Policy_Event_Remove::execute() must be an array, object given, called in /home/matt/workspace/application/classes/model/user.php on line 41 and defined ~ APPPATH/classes/policy/event/remove.php [ 5 ]
--
#0 /home/matt/workspace/application/classes/policy/event/remove.php(5): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/home/matt/work...', 5, Array)
#1 /home/matt/workspace/application/classes/model/user.php(41): Policy_Event_Remove->execute(Object(Model_User), Object(Model_Event))
#2 /home/matt/workspace/application/classes/view/page/event/display.php(74): Model_User->can('event_remove', Object(Model_Event))
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->remove_event()
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('remove_event', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('remove_event')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??????<i...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees}...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????</select>?...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#17 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#18 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#19 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#20 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#21 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#22 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#23 [internal function]: Abstract_Controller_Website->after()
#24 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#25 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#26 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#27 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#28 {main}
2012-04-06 15:56:26 --- ERROR: ErrorException [ 8 ]: Undefined index: user_id ~ MODPATH/orm/classes/kohana/orm.php [ 564 ]
2012-04-06 15:56:26 --- STRACE: ErrorException [ 8 ]: Undefined index: user_id ~ MODPATH/orm/classes/kohana/orm.php [ 564 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(564): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 564, Array)
#1 /home/matt/workspace/application/classes/view/page/event/index.php(24): Kohana_ORM->__get('user')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#12 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-04-06 15:59:01 --- ERROR: Kohana_Exception [ 0 ]: The character property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
2012-04-06 15:59:01 --- STRACE: Kohana_Exception [ 0 ]: The character property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 612 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(24): Kohana_ORM->__get('character')
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-06 16:08:43 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `character`.* FROM `characters` AS `character` WHERE 0 = 'name' AND `1` = 'Rookwood Shuffles' LIMIT 1 ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-06 16:08:43 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `character`.* FROM `characters` AS `character` WHERE 0 = 'name' AND `1` = 'Rookwood Shuffles' LIMIT 1 ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `charact...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(898): Kohana_ORM->_load_result(false)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(258): Kohana_ORM->find()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#5 /home/matt/workspace/application/classes/model/event.php(42): Kohana_ORM::factory('character', Array)
#6 /home/matt/workspace/application/classes/controller/event.php(59): Model_Event->create_event(Object(Model_User), Array, Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-04-06 16:09:41 --- ERROR: ErrorException [ 8 ]: Undefined index: user_id ~ MODPATH/orm/classes/kohana/orm.php [ 564 ]
2012-04-06 16:09:41 --- STRACE: ErrorException [ 8 ]: Undefined index: user_id ~ MODPATH/orm/classes/kohana/orm.php [ 564 ]
--
#0 /home/matt/workspace/modules/orm/classes/kohana/orm.php(564): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 564, Array)
#1 /home/matt/workspace/application/classes/view/page/event/display.php(27): Kohana_ORM->__get('user')
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->event()
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('event', Array)
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('event')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-04-06 16:26:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/index.php [ 24 ]
2012-04-06 16:26:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/index.php [ 24 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(24): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 24, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-04-06 16:26:22 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$character_id ~ APPPATH/classes/view/page/event/index.php [ 24 ]
2012-04-06 16:26:22 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$character_id ~ APPPATH/classes/view/page/event/index.php [ 24 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/index.php(24): Kohana_Core::error_handler(8, 'Undefined prope...', '/home/matt/work...', 24, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<table id="e...', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<table id="e...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#11 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Index))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#18 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#21 {main}