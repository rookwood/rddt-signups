<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-04-07 18:42:02 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/display.php [ 63 ]
2012-04-07 18:42:02 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/display.php [ 63 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/display.php(63): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 63, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->characters()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('characters', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('characters')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-04-07 18:42:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/display.php [ 63 ]
2012-04-07 18:42:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: out ~ APPPATH/classes/view/page/event/display.php [ 63 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/display.php(63): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 63, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->characters()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('characters', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('characters')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#13 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-04-07 20:31:22 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/view/page/event/display.php [ 86 ]
2012-04-07 20:31:22 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/view/page/event/display.php [ 86 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-07 20:32:01 --- ERROR: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/display.php [ 85 ]
2012-04-07 20:32:01 --- STRACE: ErrorException [ 8 ]: Undefined variable: event_data ~ APPPATH/classes/view/page/event/display.php [ 85 ]
--
#0 /home/matt/workspace/application/classes/view/page/event/display.php(85): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/work...', 85, Array)
#1 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->withdraw()
#2 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('withdraw', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('withdraw')
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{#withdraw}}?<...')
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</form...')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees}...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>?????</li>???...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????</select>?...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^characters}}...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#17 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#18 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#19 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#20 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#21 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#22 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#23 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#24 [internal function]: Abstract_Controller_Website->after()
#25 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#26 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#27 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#28 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#29 {main}
2012-04-07 20:32:17 --- ERROR: ErrorException [ 8 ]: Undefined property: Policy_Event_Withdraw::$user ~ APPPATH/classes/policy/event/withdraw.php [ 16 ]
2012-04-07 20:32:17 --- STRACE: ErrorException [ 8 ]: Undefined property: Policy_Event_Withdraw::$user ~ APPPATH/classes/policy/event/withdraw.php [ 16 ]
--
#0 /home/matt/workspace/application/classes/policy/event/withdraw.php(16): Kohana_Core::error_handler(8, 'Undefined prope...', '/home/matt/work...', 16, Array)
#1 /home/matt/workspace/application/classes/model/user.php(41): Policy_Event_Withdraw->execute(Object(Model_User), Array)
#2 /home/matt/workspace/application/classes/view/page/event/display.php(85): Model_User->can('event_withdraw', Array)
#3 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->withdraw()
#4 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('withdraw', Array)
#5 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('withdraw')
#6 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{#withdraw}}?<...')
#7 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</form...')
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees}...')
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>?????</li>???...')
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????</select>?...')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^characters}}...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#17 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#18 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#19 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#20 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#21 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#22 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#23 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#24 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#25 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#26 [internal function]: Abstract_Controller_Website->after()
#27 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#28 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#29 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#30 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#31 {main}
2012-04-07 20:33:22 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'NOT_SIGNED_UP' ~ APPPATH/classes/policy/event/withdraw.php [ 33 ]
2012-04-07 20:33:22 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'NOT_SIGNED_UP' ~ APPPATH/classes/policy/event/withdraw.php [ 33 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-07 20:34:09 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `signup`.* FROM `signups` AS `signup` WHERE 0 = 'character_id' AND `1` = '1' LIMIT 1 ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-07 20:34:09 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'where clause' [ SELECT `signup`.* FROM `signups` AS `signup` WHERE 0 = 'character_id' AND `1` = '1' LIMIT 1 ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `signup`...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(972): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/modules/orm/classes/kohana/orm.php(898): Kohana_ORM->_load_result(false)
#3 /home/matt/workspace/modules/orm/classes/kohana/orm.php(258): Kohana_ORM->find()
#4 /home/matt/workspace/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#5 /home/matt/workspace/application/classes/policy/event/withdraw.php(23): Kohana_ORM::factory('signup', Array)
#6 /home/matt/workspace/application/classes/model/user.php(41): Policy_Event_Withdraw->execute(Object(Model_User), Array)
#7 /home/matt/workspace/application/classes/view/page/event/display.php(85): Model_User->can('event_withdraw', Array)
#8 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->withdraw()
#9 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('withdraw', Array)
#10 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('withdraw')
#11 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{#withdraw}}?<...')
#12 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</form...')
#13 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees}...')
#14 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>?????</li>???...')
#15 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????</select>?...')
#16 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^characters}}...')
#17 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('????</tbody>???...')
#18 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('</legend>????<t...')
#19 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#20 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#21 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '??')
#22 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '??')
#23 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??</ul>??</nav>...')
#24 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??</ul>??</nav>...')
#25 /home/matt/workspace/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!doctype html>...', Array)
#26 /home/matt/workspace/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#27 /home/matt/workspace/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#28 /home/matt/workspace/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#29 /home/matt/workspace/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#30 /home/matt/workspace/application/classes/abstract/controller/website.php(68): Kohana_Response->body(Object(View_Page_Event_Display))
#31 [internal function]: Abstract_Controller_Website->after()
#32 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#33 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#34 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#35 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#36 {main}
2012-04-07 20:34:42 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana_Exception::message() ~ APPPATH/classes/controller/event.php [ 270 ]
2012-04-07 20:34:42 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana_Exception::message() ~ APPPATH/classes/controller/event.php [ 270 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-07 20:35:09 --- ERROR: ErrorException [ 1 ]: Cannot access protected property Kohana_Exception::$message ~ APPPATH/classes/controller/event.php [ 270 ]
2012-04-07 20:35:09 --- STRACE: ErrorException [ 1 ]: Cannot access protected property Kohana_Exception::$message ~ APPPATH/classes/controller/event.php [ 270 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-07 20:35:23 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 63 ]
2012-04-07 20:35:23 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 63 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-07 20:36:07 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 63 ]
2012-04-07 20:36:07 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 63 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-07 20:36:28 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 63 ]
2012-04-07 20:36:28 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 63 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/workspace/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Event))
#2 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-04-07 20:41:43 --- ERROR: Kohana_Exception [ 0 ]: View class does not exist: View_page_event_view_display ~ MODPATH/kostache/classes/kohana/kostache.php [ 32 ]
2012-04-07 20:41:43 --- STRACE: Kohana_Exception [ 0 ]: View class does not exist: View_page_event_view_display ~ MODPATH/kostache/classes/kohana/kostache.php [ 32 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(274): Kohana_Kostache::factory('page/event/view...')
#1 [internal function]: Controller_Event->action_withdraw()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-04-07 20:51:15 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Signup::andwhere() ~ APPPATH/classes/policy/event/withdraw.php [ 26 ]
2012-04-07 20:51:15 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Signup::andwhere() ~ APPPATH/classes/policy/event/withdraw.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-07 20:51:24 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_MySQL_Result::loaded() ~ APPPATH/classes/policy/event/withdraw.php [ 29 ]
2012-04-07 20:51:24 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_MySQL_Result::loaded() ~ APPPATH/classes/policy/event/withdraw.php [ 29 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-04-07 20:54:24 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry '2-1' for key 'unique' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('2', '1') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-04-07 20:54:24 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry '2-1' for key 'unique' [ INSERT INTO `signups` (`event_id`, `character_id`) VALUES ('2', '1') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/workspace/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `si...', false, Array)
#1 /home/matt/workspace/modules/orm/classes/kohana/orm.php(1413): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/workspace/application/classes/controller/event.php(168): Kohana_ORM->add('characters', Object(Model_Character))
#3 [internal function]: Controller_Event->action_signup()
#4 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-04-07 20:59:12 --- ERROR: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/controller/event.php [ 186 ]
2012-04-07 20:59:12 --- STRACE: ErrorException [ 8 ]: Undefined index: status ~ APPPATH/classes/controller/event.php [ 186 ]
--
#0 /home/matt/workspace/application/classes/controller/event.php(186): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/work...', 186, Array)
#1 [internal function]: Controller_Event->action_signup()
#2 /home/matt/workspace/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/workspace/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/workspace/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/workspace/public_html/index.php(109): Kohana_Request->execute()
#6 {main}