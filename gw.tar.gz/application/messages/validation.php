<?php defined('SYSPATH') or die('No direct script access.');

return array(
	'unique'         => ':field is already in use, please choose another.',
);
