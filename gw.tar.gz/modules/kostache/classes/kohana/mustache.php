<?php defined('SYSPATH') or die('No direct script access.');

class Kohana_Mustache extends Mustache {}
