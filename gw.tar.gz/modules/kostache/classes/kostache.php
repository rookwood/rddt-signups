<?php defined('SYSPATH') or die('No direct script access.');

abstract class Kostache extends Kohana_Kostache {  }
