# About Kostache

Kostache is a Kohana module for using [Mustache](http://defunkt.github.com/mustache/) templates in your application.

Mustache is a logic-less template class. It is impossible to embed logic into mustache files.

This module requires mustache.php and includes it as a git submodule.  See [Working With Git](tutorials.git) for more information about managing submodules.