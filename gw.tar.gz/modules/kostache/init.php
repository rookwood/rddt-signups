<?php defined('SYSPATH') or die('No direct script access.');

// Load Mustache for PHP
include Kohana::find_file('vendor', 'mustache/Mustache');
