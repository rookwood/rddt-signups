ProfilerToolbar v0.2.4 for Kohana 3.2
===============
ProfilerToolbar it is another realization of the DebugToolbar written by Aaron Forsander, but has additional features.

**Demo**, description and usage instructions: http://alertdevelop.ru/projects/profilertoolbar

How it looks
-----

**HTML output**

![Swipe View](http://alertdevelop.ru/img/profilertoolbar/github/toolbar.png)

**FireBug output**

![Swipe View](http://alertdevelop.ru/img/profilertoolbar/github/firebug.png)

**Error page**

![Swipe View](http://alertdevelop.ru/img/profilertoolbar/github/errorpage.png)


For more information visit http://alertdevelop.ru/projects/profilertoolbar