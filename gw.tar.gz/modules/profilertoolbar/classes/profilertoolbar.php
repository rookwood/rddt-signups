<?php defined('SYSPATH') or die('No direct script access.');

class ProfilerToolbar extends Kohana_ProfilerToolbar {}