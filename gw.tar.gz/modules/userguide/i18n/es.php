<?php defined('SYSPATH') or die('No direct script access.');

return array
(
	'User Guide' => 'Guía de Usuario'
);
