<?php defined('SYSPATH') or die('No direct script access.');

return array
(
	'French' => 'Français',
	'Hello, world!' => 'Bonjour, monde!',
);